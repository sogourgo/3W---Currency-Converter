package com.example.model ;

public class Direct{

	private String report;

	public Direct(String report){
		this.report = report ;
	}

	public String getReport(){
		return report;
	}
	



}
